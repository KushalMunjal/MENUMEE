package Models.Client;

public class CustomerDataField{


    //Customer DataFields
    String SourceSystemCustomerCode;
    String UniqueIdentifier;
    String SourceSystemCustomerCreationDate;
    String EkycOTPbased;
    String Segment;
    String SegmentStartDate;
    String Products;
    String Status;
    String EffectiveDate;
    String ConstitutionType;
    String Prefix;
    String FirstName;
    String MiddleName;

    String LastName;
    String Alias;
    String FatherPrefix;
    String FatherFirstName;
    String FatherMiddleName;
    String FatherLastName;
    String SpousePrefix;
    String SpouseFirstName;
    String SpouseMiddleName;
    String SpouseLastName;
    String MotherPrefix;
    String MotherFirstName;
    String MotherMiddleName;
    String MotherLastName;
    String Minor;
    String Gender;
    String MaritalStatus;
    String OccupationType;
    String NccupationTypeOther;
    String NatureofBusiness;
    String NatureofBusinessOther;
    String ProofOfIDSubmitted;
    String DateofBirthIncorporation;
    String WorkEmail;
    String PersonalEmail;
    String WorkMobileISD;
    String WorkMobileNumber;
    String PersonalMobileISD;
    String PersonalMobileNumber;
    String PermanentAddressCountry;
    String PermanentAddressZipCode;
    String PermanentAddressLine1;
    String PermanentAddressLine2;
    String PermanentAddressLine3;
    String PermanentAddressDistrict;
    String PermanentAddressCity;
    String PermanentAddressState;
    String PermanentAddressOtherState;
    String PermanentAddressDocument;
    String PermanentAddressDocumentOthersValue;
    String CorrespondenceAddressCountry;
    String CorrespondenceAddressZipCode;
    String CorrespondenceAddressLine1;
    String CorrespondenceAddressLine2;
    String CorrespondenceAddressLine3;
    String CorrespondenceAddressDistrict;
    String CorrespondenceAddressCity;
    String CorrespondenceAddressState;
    String CorrespondenceAddressOtherState;
    String CorrespondenceAddressDocument;
    String Citizenship;
    String Nationality;
    String CountryOfResidence;
    String CountryOfBirth;
    String BirthCity;
    String TaxResidencyCountry;
    String TaxResidencyStartDate;
    String TaxResidencyEndDate;
    String TaxIdentificationNumber;
    String PassportIssueCountry;
    String PassportNumber;
    String PassportExpiryDate;
    String GSTIN;
    String GSTINStartDate;
    String GSTINEndDate;
    String VoterIdNumber;
    String DrivingLicenseNumber;
    String DrivingLicenseExpiryDate;
    String AadhaarNumber;
    String AadhaarVaultReferenceNumber;
    String NREGANumber;
    String NPRLetterNumber;
    String DirectorIdentificationNumber;
    String FormSixty;
    String PAN;
    String CKYCNumber;
    String CompanyIdentificationNumber;
    String CompanyRegistrationNumber;
    String CompanyRegistrationCountry;
    String GlobalIntermediaryIdentificationNumber;
    String KYCAttestationType;
    String KYCDateOfDeclaration;
    String KYCPlaceOfDeclaration;
    String KYCVerificationDate;
    String KYCEmployeeName;
    String KYCEmployeeDesignation;
    String KYCVerificationBranch;
    String KYCEmployeeCode;
    String IdentityDocument;
    String Listed;
    String CountryoFOperation;
    String ApplicationRefNumber;
    String DocumentRefNumber;
    String RegAMLRisk;
    String RegAMLRiskSpecialCategory;
    String RegAMLRiskSpecialCategoryStartDate;
    String RegAMLRiskLastRiskReviewDate;
    String RegAMLRiskNextRiskReviewDate;
    String IncomeRange;
    int ExactIncome;
    String IncomeCurrency;
    String IncomeEffectiveDate;
    String IncomeDescription;
    String IncomeDocument;
    int ExactNetworth;
    String NetworthCurrency;
    String NetworthEffectiveDate;
    String NetworthDescription;
    String NetworthDocument;
    String PoliticallyExposed;
    String PoliticallyExposedClassification;
    String AdverseReputation;
    String AdverseReputationClassification;
    String AdverseReputationDetails;
    String ScreeningProfile;
    String ScreeningReportwhenNil;
    String RiskProfile;
    String RiskRatingReportWhenLow;
    String Tags;
    String FamilyCode;
    String Channel;
    String ContactPersonFirstName1;
    String ContactPersonMiddleName1;
    String ContactPersonLastName1;
    String ContactPersonFirstName2;
    String ContactPersonMiddleName2;
    String ContactPersonLastName2;
    String ContactPersonDesignation1;
    String ContactPersonDesignation2;
    String ContactPersonMobileISD;
    String ContactPersonMobileNo2;
    String ContactPersonMobileISD2;
    //String ContactPersonMobileNo2;
    String ContactPersonEmailId1;
    String ContactPersonEmailId2;
    String EducationalQualification;
    String CommencementDate;
    String MaidenFirstName;
    String MaidenMiddleName;
    String MaidenLastName;
    String RelatedPersonCountforCKYC;
    String Notes;












}

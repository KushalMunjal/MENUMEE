package Models.Client;

import javax.swing.plaf.synth.SynthTreeUI;

public class MainRequestDataField {

    String requestID = "1";
    String sourceSystemName = "TW";
    String apiToken = "1111";
    String purpose = "01,02";
    String sessionKey = "22222";

}

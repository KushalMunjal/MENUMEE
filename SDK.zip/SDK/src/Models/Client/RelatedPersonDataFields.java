package Models.Client;

public class RelatedPersonDataFields extends CustomerDataField {

    String SourceSystemCustomerCode;
    String SourceSystemCustomerCreationDate;
    String UniqueIdentifier;
    String ConstitutionType;
    String Prefix;
    String FirstName;
    String MiddleName;
    String LastName;
    String Alias;
    String FatherPrefix;
    String FatherFirstName;
    String FatherMiddleName;
    String FatherLastName;
    String SpousePrefix;
    String SpouseFirstName;
    String SpouseMiddleName;
    String SpouseLastName;
    String MotherPrefix;
    String MotherFirstName;
    String MotherMiddleName;
    String MotherLastName;
    String Minor;
    String Gender;
    String DateofBirth;
    String WorkEmail;
    String PersonalEmail;
    String PermanentAddressCountry;
    String PermanentAddressOtherState;
    String PermanentAddressZipCode;
    String PermanentAddressLine1;
    String PermanentAddressLine2;
    String PermanentAddressLine3;
    String PermanentAddressDistrict;
    String PermanentAddressCity;
    String PermanentAddressState;
    //Repeat String PermanentAddressOtherState;
    String PermanentAddressDocument;
    String PermanentAddressDocumentOthersValue;
    String CorrespondenceAddressCountry;
    String CorrespondenceAddressZipCode;
    String CorrespondenceAddressLine1;
    String CorrespondenceAddressLine2;
    String CorrespondenceAddressLine3;
    String CorrespondenceAddressDistrict;
    String CorrespondenceAddressCity;
    String CorrespondenceAddressState;
    String CorrepondenceAddressStateOther;
    String CorrespondenceAddressDocument;
    String Citizenship;
    String Nationality;
    String CountryOfResidence;
    String CountryOfBirth;
    String BirthCity;
    String TaxResidencyCountry;
    String TaxResidencyStartDate;
    String TaxResidencyEndDate;
    String TaxIdentificationNumber;
    String PassportIssueCountry;
    String PassportNumber;
    String PassportExpiryDate;
    String GSTIN;
    String GSTINStartDate;
    String GSTINEndDate;
    String VoterIdNumber;
    String DrivingLicenseNumber;
    String DrivingLicenseExpiryDate;
    String AadhaarNumber;
    String AadhaarVaultReferenceNumber;
    String NREGANumber;
    String NPRLetterNumber;
    String DirectorIdentificationNumber;
    String FormSixty;
    String PAN;
    String CKYCNumber;
    String IdentityDocument;
    String PoliticallyExposed;
    String PoliticallyExposedClassification;
    String AdverseReputation;
    String AdverseReputationClassification;
    String  AdverseReputationDetails;
    String  ScreeningProfile;
    String  ScreeningReportwhenNil;
    String  RiskProfile;
    String  RiskRatingReportWhenLow;
    String Tags;
    String  Notes;








}

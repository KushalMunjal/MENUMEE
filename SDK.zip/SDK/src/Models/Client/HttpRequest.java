package Models.Client;
import Encryption.Encryption;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class HttpRequest {
    public static void main(String[] args) {
        MainRequestDataField m1 = new MainRequestDataField();
        Encryption e1 = new Encryption();
         String  urlGet = "https://tenant1-sb.trackwizz.com:3009/AS501";
        try {
            URL urliobjget = new URL(urlGet);
            HttpURLConnection con= (HttpURLConnection) urliobjget.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("Accept", "application/json");
            con.setDoOutput(true);
            String jsonInputString = ();
            try(OutputStream os = con.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            try(BufferedReader br = new BufferedReader(
                    new InputStreamReader(con.getInputStream(), "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                System.out.println(response.toString());
            }
//            int responseCodeGet = conGet.getResponseCode();
//            System.out.println("Sending Get Request URl to "+urlGet);
//            System.out.println("Response Code: "+responseCodeGet);
//            BufferedReader inGet = new BufferedReader(new InputStreamReader(conGet.getInputStream()));
//            String inputLineGet;
//            StringBuffer responseGet = new StringBuffer();
//            while((inputLineGet = inGet.readLine())!=null){
//                responseGet.append(inputLineGet);
//            }
//            inGet.close();
//            System.out.println("Response: "+responseGet.toString());

        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
}

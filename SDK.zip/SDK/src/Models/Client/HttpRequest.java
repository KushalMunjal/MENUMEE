package Models.Client;

import Encryption.Encryption;
import Models.API.AS501APIRequest;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.Key;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;


public class HttpRequest {
    private String encryptedData;
    private String encryptionKey;
    private String signature;
    private String requestId;

    public static void main(String[] args) {
        Gson gson = new Gson();
        HttpRequest h1 = new HttpRequest();
        Encryption e1 = new Encryption();
        AS501APIRequest a1 = new AS501APIRequest();
        AS501APIRequest.Customer c1 = new AS501APIRequest.Customer();
        AS501APIRequest.RegAMLRiskSpecialCategoryDto r1 = new AS501APIRequest.RegAMLRiskSpecialCategoryDto();

        a1.setRequestId("IND2550");
        a1.setSourceSystemName("FINACLE");
        a1.setPurpose("01");

        c1.setEkycOTPbased("0");
        c1.setSegment("3");
        c1.setSegmentStartDate("11-Feb-2022");
        r1.setRegAMLRiskSpecialCategory("High Risk");
        r1.setRegAMLRiskSpecialCategoryStartDate("2023-01-01");

        List<AS501APIRequest.Customer> customerList = new ArrayList<>();
        customerList.add(c1);
        a1.setCustomerList(customerList);

        List<AS501APIRequest.RegAMLRiskSpecialCategoryDto> riskCategoryList = new ArrayList<>();
        riskCategoryList.add(r1);
        c1.setRegAMLRiskSpecialCategoryDtoList(riskCategoryList);

        try{

            String json = gson.toJson(a1);
            System.out.println(json);
            FileInputStream publicKeyInput = new FileInputStream("H:/Temporary/Vaibhav.Soni/Marwadi/ValidDocument/public.cer");
            CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
            X509Certificate publicCertificate = (X509Certificate)certificateFactory.generateCertificate(publicKeyInput);
            PublicKey publicKey = publicCertificate.getPublicKey();

            FileInputStream privateKeyInput = new FileInputStream("H:/Temporary/Vaibhav.Soni/Marwadi/ValidDocument/private.pfx");
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            char[] password = "marwadi".toCharArray();
            keyStore.load(privateKeyInput,password);
            String alias = keyStore.aliases().nextElement();
            Key privateKey = keyStore.getKey(alias,password);
            e1.encryptData(json,publicKey, (PrivateKey) privateKey);
            h1.requestId =
            h1.encryptedData =
            h1.encryptionKey =
            h1.signature = 
            String jsondata = gson.toJson(h1);
            String  urlGet = "https://tenantdev1.tssconsultancy.com:5309/AS501";
                URL urliobjget = new URL(urlGet);
                HttpURLConnection con= (HttpURLConnection) urliobjget.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json");
                con.setRequestProperty("domain", "https://tenantdev1.tssconsultancy.com:5309");
                con.setRequestProperty("cluster", "CL1_User");
                con.setRequestProperty("apiToken", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJBcGlTdWJzY3JpcHRpb25JZCI6IjEiLCJUZW5hbnRJZGVudGlmaWVyIjoiUGFydGhNYXN0ZXJJZGVudGlmaWVyIiwiQXBpSWQiOiIxIiwiRW5jcnlwdGlvblByb3ZpZGVySWQiOiI2IiwiQWdlbmN5SWQiOiI4IiwiZXhwIjoxODY1NzAxODAwLCJpc3MiOiJ0cmFja3dpenpTYWFTR2xvYmFsIiwiYXVkIjoiYW5ndWxhckNsaWVudCJ9.5PSrgz4EVjLMpke50BYG7K0RFWapR83ktCC9s_q4_Zw");
                con.setDoOutput(true);



                try(DataOutputStream outputStream = new DataOutputStream(con.getOutputStream())){
                    outputStream.writeBytes(jsondata);
                    outputStream.flush();
                }

                System.out.println(jsondata);

                StringBuilder response = new StringBuilder();
                try(BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()))){
                    String line;
                    while((line= reader.readLine())!=null){
                        response.append(line);
                    }
                }
                System.out.println(response.toString());
                System.out.println(con.getResponseMessage());
                System.out.println(con.getResponseCode());

            }catch (Exception e){
                e.printStackTrace();
            }

    }
}

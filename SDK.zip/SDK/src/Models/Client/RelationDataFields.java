package Models.Client;

public class RelationDataFields {
    String CustomerSourceSystemCode;
    String RelatedPersonSourceSystemCode;
    String RelationCode;
    String RelationStartDate;
    String RelationEndDate;
    String ShareHoldingPercentage;
    String RelationNotes;

    private RelationDataFields(String CustomerSourceSystemCode,String RelatedPersonSourceSystemCode,String RelationCode,String RelationStartDate,String RelationEndDate,String ShareHoldingPercentage,String RelationNotes){
        this.CustomerSourceSystemCode = CustomerSourceSystemCode;
        this.RelatedPersonSourceSystemCode = RelatedPersonSourceSystemCode;
        this.RelationCode = RelationCode;
        this.RelationStartDate = RelationStartDate;
        this.RelationEndDate = RelationEndDate;
        this.ShareHoldingPercentage = ShareHoldingPercentage;
        this.RelationNotes = RelationNotes;
    }

}

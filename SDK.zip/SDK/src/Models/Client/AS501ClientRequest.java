package Models.Client;

import Models.Client.MainRequestDataField;
import java.util.List;

public class AS501ClientRequest extends CustomerDataField {

    public AS501ClientRequest(String RequestID, String SourceSytemName, String Purpose, List<String> CustomerList,List<String>RegAMLRiskSpecislCategoryDtoList,List<String>TaxDetailDtoList,String GUID) {
//        this.requestID = RequestID;
//        this.SourceSystemName = SourceSytemName;
//        this.Purpose = Purpose;
        this.EkycOTPbased = String.valueOf(CustomerList.add(EkycOTPbased));
    }
}

package Models.API;

import java.util.List;

public class AS501APIResponse {
    private String RequestId;
    private String OverallStatus;
    private String ValidationCode;
    private String ValidationDescription;
    private List<CustomerResponse> CustomerResponse;
    private String RelatedPersonResponse;
    private String RelatedPersonRelationResponse;

    // Getters and Setters

    public String getRequestId() {
        return RequestId;
    }

    public void setRequestId(String requestId) {
        RequestId = requestId;
    }

    public String getOverallStatus() {
        return OverallStatus;
    }

    public void setOverallStatus(String overallStatus) {
        OverallStatus = overallStatus;
    }

    public String getValidationCode() {
        return ValidationCode;
    }

    public void setValidationCode(String validationCode) {
        ValidationCode = validationCode;
    }

    public String getValidationDescription() {
        return ValidationDescription;
    }

    public void setValidationDescription(String validationDescription) {
        ValidationDescription = validationDescription;
    }

    public List<AS501APIResponse.CustomerResponse> getCustomerResponse() {
        return CustomerResponse;
    }

    public void setCustomerResponse(List<AS501APIResponse.CustomerResponse> customerResponse) {
        CustomerResponse = customerResponse;
    }

    public String getRelatedPersonResponse() {
        return RelatedPersonResponse;
    }

    public void setRelatedPersonResponse(String relatedPersonResponse) {
        RelatedPersonResponse = relatedPersonResponse;
    }

    public String getRelatedPersonRelationResponse() {
        return RelatedPersonRelationResponse;
    }

    public void setRelatedPersonRelationResponse(String relatedPersonRelationResponse) {
        RelatedPersonRelationResponse = relatedPersonRelationResponse;
    }

    public static class CustomerResponse {
        private String SourceSystemCustomerCode;
        private String ValidationOutcome;
        private String SuggestedAction;
        private List<PurposeResponse> PurposeResponse;
        private String ValidationCode;
        private String ValidationDescription;
        private int ValidationFailureCount;

        public String getSourceSystemCustomerCode() {
            return SourceSystemCustomerCode;
        }

        public void setSourceSystemCustomerCode(String sourceSystemCustomerCode) {
            SourceSystemCustomerCode = sourceSystemCustomerCode;
        }

        public String getValidationOutcome() {
            return ValidationOutcome;
        }

        public void setValidationOutcome(String validationOutcome) {
            ValidationOutcome = validationOutcome;
        }

        public String getSuggestedAction() {
            return SuggestedAction;
        }

        public void setSuggestedAction(String suggestedAction) {
            SuggestedAction = suggestedAction;
        }

        public List<AS501APIResponse.CustomerResponse.PurposeResponse> getPurposeResponse() {
            return PurposeResponse;
        }

        public void setPurposeResponse(List<AS501APIResponse.CustomerResponse.PurposeResponse> purposeResponse) {
            PurposeResponse = purposeResponse;
        }

        public String getValidationCode() {
            return ValidationCode;
        }

        public void setValidationCode(String validationCode) {
            ValidationCode = validationCode;
        }

        public String getValidationDescription() {
            return ValidationDescription;
        }

        public void setValidationDescription(String validationDescription) {
            ValidationDescription = validationDescription;
        }

        public int getValidationFailureCount() {
            return ValidationFailureCount;
        }

        public void setValidationFailureCount(int validationFailureCount) {
            ValidationFailureCount = validationFailureCount;
        }
// Getters and Setters

        public static class PurposeResponse {
            private String Purpose;
            private String PurposeCode;
            private String ValidationCode;
            private String ValidationDescription;
            private int ValidationFailureCount;
            private Data Data;

            // Getters and Setters


            public String getPurpose() {
                return Purpose;
            }

            public void setPurpose(String purpose) {
                Purpose = purpose;
            }

            public String getPurposeCode() {
                return PurposeCode;
            }

            public void setPurposeCode(String purposeCode) {
                PurposeCode = purposeCode;
            }

            public String getValidationCode() {
                return ValidationCode;
            }

            public void setValidationCode(String validationCode) {
                ValidationCode = validationCode;
            }

            public String getValidationDescription() {
                return ValidationDescription;
            }

            public void setValidationDescription(String validationDescription) {
                ValidationDescription = validationDescription;
            }

            public int getValidationFailureCount() {
                return ValidationFailureCount;
            }

            public void setValidationFailureCount(int validationFailureCount) {
                ValidationFailureCount = validationFailureCount;
            }

            public AS501APIResponse.CustomerResponse.PurposeResponse.Data getData() {
                return Data;
            }

            public void setData(AS501APIResponse.CustomerResponse.PurposeResponse.Data data) {
                Data = data;
            }

            public static class Data {
                private String HitsDetected;
                private int HitsCount;
                private String ConfirmedHit;
                private String ReportData; // Assuming Base 64 Data is stored as a string

                // Getters and Setters

                public String getHitsDetected() {
                    return HitsDetected;
                }

                public void setHitsDetected(String hitsDetected) {
                    HitsDetected = hitsDetected;
                }

                public int getHitsCount() {
                    return HitsCount;
                }

                public void setHitsCount(int hitsCount) {
                    HitsCount = hitsCount;
                }

                public String getConfirmedHit() {
                    return ConfirmedHit;
                }

                public void setConfirmedHit(String confirmedHit) {
                    ConfirmedHit = confirmedHit;
                }

                public String getReportData() {
                    return ReportData;
                }

                public void setReportData(String reportData) {
                    ReportData = reportData;
                }
            }
        }
    }
}
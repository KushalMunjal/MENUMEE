package Models.API;

public class AS501APIRequest {
}

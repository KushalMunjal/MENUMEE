package Models.API;

import java.util.List;

public class AS501APIRequest {
    private String requestId;
    private String sourceSystemName;
    private String purpose;
    private List<Customer> customerList;
    private String GUID;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getSourceSystemName() {
        return sourceSystemName;
    }

    public void setSourceSystemName(String sourceSystemName) {
        this.sourceSystemName = sourceSystemName;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }

    public void setCustomerList(List<Customer> customerList) {
        this.customerList = customerList;
    }

    public String getGUID() {
        return GUID;
    }

    public void setGUID(String GUID) {
        this.GUID = GUID;
    }

    public static class Customer {
        private String ekycOTPbased;
        private String segment;

        public String getEkycOTPbased() {
            return ekycOTPbased;
        }

        public void setEkycOTPbased(String ekycOTPbased) {
            this.ekycOTPbased = ekycOTPbased;
        }

        public String getSegment() {
            return segment;
        }

        public void setSegment(String segment) {
            this.segment = segment;
        }

        public String getSegmentStartDate() {
            return segmentStartDate;
        }

        public void setSegmentStartDate(String segmentStartDate) {
            this.segmentStartDate = segmentStartDate;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getEffectiveDate() {
            return effectiveDate;
        }

        public void setEffectiveDate(String effectiveDate) {
            this.effectiveDate = effectiveDate;
        }

        public String getMinor() {
            return minor;
        }

        public void setMinor(String minor) {
            this.minor = minor;
        }

        public String getMaritalStatus() {
            return maritalStatus;
        }

        public void setMaritalStatus(String maritalStatus) {
            this.maritalStatus = maritalStatus;
        }

        public String getOccupationType() {
            return occupationType;
        }

        public void setOccupationType(String occupationType) {
            this.occupationType = occupationType;
        }

        public String getOccupationTypeOther() {
            return occupationTypeOther;
        }

        public void setOccupationTypeOther(String occupationTypeOther) {
            this.occupationTypeOther = occupationTypeOther;
        }

        public String getNatureOfBusinessOther() {
            return natureOfBusinessOther;
        }

        public void setNatureOfBusinessOther(String natureOfBusinessOther) {
            this.natureOfBusinessOther = natureOfBusinessOther;
        }

        public String getCompanyIdentificationNumber() {
            return companyIdentificationNumber;
        }

        public void setCompanyIdentificationNumber(String companyIdentificationNumber) {
            this.companyIdentificationNumber = companyIdentificationNumber;
        }

        public String getCompanyRegistrationNumber() {
            return companyRegistrationNumber;
        }

        public void setCompanyRegistrationNumber(String companyRegistrationNumber) {
            this.companyRegistrationNumber = companyRegistrationNumber;
        }

        public String getCompanyRegistrationCountry() {
            return companyRegistrationCountry;
        }

        public void setCompanyRegistrationCountry(String companyRegistrationCountry) {
            this.companyRegistrationCountry = companyRegistrationCountry;
        }

        public String getGlobalIntermediaryIdentificationNumber() {
            return globalIntermediaryIdentificationNumber;
        }

        public void setGlobalIntermediaryIdentificationNumber(String globalIntermediaryIdentificationNumber) {
            this.globalIntermediaryIdentificationNumber = globalIntermediaryIdentificationNumber;
        }

        public String getKycAttestationType() {
            return kycAttestationType;
        }

        public void setKycAttestationType(String kycAttestationType) {
            this.kycAttestationType = kycAttestationType;
        }

        public String getKycDateOfDeclaration() {
            return kycDateOfDeclaration;
        }

        public void setKycDateOfDeclaration(String kycDateOfDeclaration) {
            this.kycDateOfDeclaration = kycDateOfDeclaration;
        }

        public String getKycPlaceOfDeclaration() {
            return kycPlaceOfDeclaration;
        }

        public void setKycPlaceOfDeclaration(String kycPlaceOfDeclaration) {
            this.kycPlaceOfDeclaration = kycPlaceOfDeclaration;
        }

        public String getKycVerificationDate() {
            return kycVerificationDate;
        }

        public void setKycVerificationDate(String kycVerificationDate) {
            this.kycVerificationDate = kycVerificationDate;
        }

        public String getKycEmployeeName() {
            return kycEmployeeName;
        }

        public void setKycEmployeeName(String kycEmployeeName) {
            this.kycEmployeeName = kycEmployeeName;
        }

        public String getKycEmployeeDesignation() {
            return kycEmployeeDesignation;
        }

        public void setKycEmployeeDesignation(String kycEmployeeDesignation) {
            this.kycEmployeeDesignation = kycEmployeeDesignation;
        }

        public String getKycVerificationBranch() {
            return kycVerificationBranch;
        }

        public void setKycVerificationBranch(String kycVerificationBranch) {
            this.kycVerificationBranch = kycVerificationBranch;
        }

        public String getKycEmployeeCode() {
            return kycEmployeeCode;
        }

        public void setKycEmployeeCode(String kycEmployeeCode) {
            this.kycEmployeeCode = kycEmployeeCode;
        }

        public String getListed() {
            return listed;
        }

        public void setListed(String listed) {
            this.listed = listed;
        }

        public String getApplicationRefNumber() {
            return applicationRefNumber;
        }

        public void setApplicationRefNumber(String applicationRefNumber) {
            this.applicationRefNumber = applicationRefNumber;
        }

        public String getDocumentRefNumber() {
            return documentRefNumber;
        }

        public void setDocumentRefNumber(String documentRefNumber) {
            this.documentRefNumber = documentRefNumber;
        }

        public String getRegAMLRisk() {
            return regAMLRisk;
        }

        public void setRegAMLRisk(String regAMLRisk) {
            this.regAMLRisk = regAMLRisk;
        }

        public String getRegAMLRiskLastRiskReviewDate() {
            return regAMLRiskLastRiskReviewDate;
        }

        public void setRegAMLRiskLastRiskReviewDate(String regAMLRiskLastRiskReviewDate) {
            this.regAMLRiskLastRiskReviewDate = regAMLRiskLastRiskReviewDate;
        }

        public String getRegAMLRiskNextRiskReviewDate() {
            return regAMLRiskNextRiskReviewDate;
        }

        public void setRegAMLRiskNextRiskReviewDate(String regAMLRiskNextRiskReviewDate) {
            this.regAMLRiskNextRiskReviewDate = regAMLRiskNextRiskReviewDate;
        }

        public String getIncomeRange() {
            return incomeRange;
        }

        public void setIncomeRange(String incomeRange) {
            this.incomeRange = incomeRange;
        }

        public double getExactIncome() {
            return exactIncome;
        }

        public void setExactIncome(double exactIncome) {
            this.exactIncome = exactIncome;
        }

        public String getIncomeCurrency() {
            return incomeCurrency;
        }

        public void setIncomeCurrency(String incomeCurrency) {
            this.incomeCurrency = incomeCurrency;
        }

        public String getIncomeEffectiveDate() {
            return incomeEffectiveDate;
        }

        public void setIncomeEffectiveDate(String incomeEffectiveDate) {
            this.incomeEffectiveDate = incomeEffectiveDate;
        }

        public String getIncomeDescription() {
            return incomeDescription;
        }

        public void setIncomeDescription(String incomeDescription) {
            this.incomeDescription = incomeDescription;
        }

        public String getIncomeDocument() {
            return incomeDocument;
        }

        public void setIncomeDocument(String incomeDocument) {
            this.incomeDocument = incomeDocument;
        }

        public double getExactNetworth() {
            return exactNetworth;
        }

        public void setExactNetworth(double exactNetworth) {
            this.exactNetworth = exactNetworth;
        }

        public String getNetworthCurrency() {
            return networthCurrency;
        }

        public void setNetworthCurrency(String networthCurrency) {
            this.networthCurrency = networthCurrency;
        }

        public String getNetworthEffectiveDate() {
            return networthEffectiveDate;
        }

        public void setNetworthEffectiveDate(String networthEffectiveDate) {
            this.networthEffectiveDate = networthEffectiveDate;
        }

        public String getNetworthDescription() {
            return networthDescription;
        }

        public void setNetworthDescription(String networthDescription) {
            this.networthDescription = networthDescription;
        }

        public String getNetworthDocument() {
            return networthDocument;
        }

        public void setNetworthDocument(String networthDocument) {
            this.networthDocument = networthDocument;
        }

        public String getFamilyCode() {
            return familyCode;
        }

        public void setFamilyCode(String familyCode) {
            this.familyCode = familyCode;
        }

        public String getChannel() {
            return channel;
        }

        public void setChannel(String channel) {
            this.channel = channel;
        }

        public String getContactPersonFirstName1() {
            return contactPersonFirstName1;
        }

        public void setContactPersonFirstName1(String contactPersonFirstName1) {
            this.contactPersonFirstName1 = contactPersonFirstName1;
        }

        public String getContactPersonMiddleName1() {
            return contactPersonMiddleName1;
        }

        public void setContactPersonMiddleName1(String contactPersonMiddleName1) {
            this.contactPersonMiddleName1 = contactPersonMiddleName1;
        }

        public String getContactPersonLastName1() {
            return contactPersonLastName1;
        }

        public void setContactPersonLastName1(String contactPersonLastName1) {
            this.contactPersonLastName1 = contactPersonLastName1;
        }

        public String getContactPersonDesignation1() {
            return contactPersonDesignation1;
        }

        public void setContactPersonDesignation1(String contactPersonDesignation1) {
            this.contactPersonDesignation1 = contactPersonDesignation1;
        }

        public String getContactPersonFirstName2() {
            return contactPersonFirstName2;
        }

        public void setContactPersonFirstName2(String contactPersonFirstName2) {
            this.contactPersonFirstName2 = contactPersonFirstName2;
        }

        public String getContactPersonMiddleName2() {
            return contactPersonMiddleName2;
        }

        public void setContactPersonMiddleName2(String contactPersonMiddleName2) {
            this.contactPersonMiddleName2 = contactPersonMiddleName2;
        }

        public String getContactPersonLastName2() {
            return contactPersonLastName2;
        }

        public void setContactPersonLastName2(String contactPersonLastName2) {
            this.contactPersonLastName2 = contactPersonLastName2;
        }

        public String getContactPersonDesignation2() {
            return contactPersonDesignation2;
        }

        public void setContactPersonDesignation2(String contactPersonDesignation2) {
            this.contactPersonDesignation2 = contactPersonDesignation2;
        }

        public String getContactPersonMobileISD() {
            return contactPersonMobileISD;
        }

        public void setContactPersonMobileISD(String contactPersonMobileISD) {
            this.contactPersonMobileISD = contactPersonMobileISD;
        }

        public String getContactPersonMobileNo() {
            return contactPersonMobileNo;
        }

        public void setContactPersonMobileNo(String contactPersonMobileNo) {
            this.contactPersonMobileNo = contactPersonMobileNo;
        }

        public String getContactPersonMobileISD2() {
            return contactPersonMobileISD2;
        }

        public void setContactPersonMobileISD2(String contactPersonMobileISD2) {
            this.contactPersonMobileISD2 = contactPersonMobileISD2;
        }

        public String getContactPersonMobileNo2() {
            return contactPersonMobileNo2;
        }

        public void setContactPersonMobileNo2(String contactPersonMobileNo2) {
            this.contactPersonMobileNo2 = contactPersonMobileNo2;
        }

        public String getContactPersonEmailId1() {
            return contactPersonEmailId1;
        }

        public void setContactPersonEmailId1(String contactPersonEmailId1) {
            this.contactPersonEmailId1 = contactPersonEmailId1;
        }

        public String getContactPersonEmailId2() {
            return contactPersonEmailId2;
        }

        public void setContactPersonEmailId2(String contactPersonEmailId2) {
            this.contactPersonEmailId2 = contactPersonEmailId2;
        }

        public String getCommencementDate() {
            return commencementDate;
        }

        public void setCommencementDate(String commencementDate) {
            this.commencementDate = commencementDate;
        }

        public String getMaidenPrefix() {
            return maidenPrefix;
        }

        public void setMaidenPrefix(String maidenPrefix) {
            this.maidenPrefix = maidenPrefix;
        }

        public String getMaidenFirstName() {
            return maidenFirstName;
        }

        public void setMaidenFirstName(String maidenFirstName) {
            this.maidenFirstName = maidenFirstName;
        }

        public String getMaidenMiddleName() {
            return maidenMiddleName;
        }

        public void setMaidenMiddleName(String maidenMiddleName) {
            this.maidenMiddleName = maidenMiddleName;
        }

        public String getMaidenLastName() {
            return maidenLastName;
        }

        public void setMaidenLastName(String maidenLastName) {
            this.maidenLastName = maidenLastName;
        }

        public int getRelatedPersonCountforCKYC() {
            return relatedPersonCountforCKYC;
        }

        public void setRelatedPersonCountforCKYC(int relatedPersonCountforCKYC) {
            this.relatedPersonCountforCKYC = relatedPersonCountforCKYC;
        }

        public String getProofOfIdSubmitted() {
            return proofOfIdSubmitted;
        }

        public void setProofOfIdSubmitted(String proofOfIdSubmitted) {
            this.proofOfIdSubmitted = proofOfIdSubmitted;
        }

        public String getProducts() {
            return products;
        }

        public void setProducts(String products) {
            this.products = products;
        }

        public String getNatureOfBusiness() {
            return natureOfBusiness;
        }

        public void setNatureOfBusiness(String natureOfBusiness) {
            this.natureOfBusiness = natureOfBusiness;
        }

        public String getEducationalQualification() {
            return educationalQualification;
        }

        public void setEducationalQualification(String educationalQualification) {
            this.educationalQualification = educationalQualification;
        }

        public String getCountryOfOperations() {
            return countryOfOperations;
        }

        public void setCountryOfOperations(String countryOfOperations) {
            this.countryOfOperations = countryOfOperations;
        }

        public List<RegAMLRiskSpecialCategoryDto> getRegAMLRiskSpecialCategoryDtoList() {
            return regAMLRiskSpecialCategoryDtoList;
        }

        public void setRegAMLRiskSpecialCategoryDtoList(List<RegAMLRiskSpecialCategoryDto> regAMLRiskSpecialCategoryDtoList) {
            this.regAMLRiskSpecialCategoryDtoList = regAMLRiskSpecialCategoryDtoList;
        }

        public List<RelatedPerson> getRelatedPersonList() {
            return relatedPersonList;
        }

        public void setRelatedPersonList(List<RelatedPerson> relatedPersonList) {
            this.relatedPersonList = relatedPersonList;
        }

        public List<CustomerRelationDto> getCustomerRelationDtoList() {
            return customerRelationDtoList;
        }

        public void setCustomerRelationDtoList(List<CustomerRelationDto> customerRelationDtoList) {
            this.customerRelationDtoList = customerRelationDtoList;
        }

        public String getConstitutionType() {
            return constitutionType;
        }

        public void setConstitutionType(String constitutionType) {
            this.constitutionType = constitutionType;
        }

        public int getConstitutionTypeId() {
            return constitutionTypeId;
        }

        public void setConstitutionTypeId(int constitutionTypeId) {
            this.constitutionTypeId = constitutionTypeId;
        }

        public String getSourceSystemCustomerCode() {
            return sourceSystemCustomerCode;
        }

        public void setSourceSystemCustomerCode(String sourceSystemCustomerCode) {
            this.sourceSystemCustomerCode = sourceSystemCustomerCode;
        }

        public String getSourceSystemCustomerCreationDate() {
            return sourceSystemCustomerCreationDate;
        }

        public void setSourceSystemCustomerCreationDate(String sourceSystemCustomerCreationDate) {
            this.sourceSystemCustomerCreationDate = sourceSystemCustomerCreationDate;
        }

        public String getUniqueIdentifier() {
            return uniqueIdentifier;
        }

        public void setUniqueIdentifier(String uniqueIdentifier) {
            this.uniqueIdentifier = uniqueIdentifier;
        }

        public String getPrefix() {
            return prefix;
        }

        public void setPrefix(String prefix) {
            this.prefix = prefix;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getMiddleName() {
            return middleName;
        }

        public void setMiddleName(String middleName) {
            this.middleName = middleName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getFatherPrefix() {
            return fatherPrefix;
        }

        public void setFatherPrefix(String fatherPrefix) {
            this.fatherPrefix = fatherPrefix;
        }

        public String getFatherFirstName() {
            return fatherFirstName;
        }

        public void setFatherFirstName(String fatherFirstName) {
            this.fatherFirstName = fatherFirstName;
        }

        public String getFatherMiddleName() {
            return fatherMiddleName;
        }

        public void setFatherMiddleName(String fatherMiddleName) {
            this.fatherMiddleName = fatherMiddleName;
        }

        public String getFatherLastName() {
            return fatherLastName;
        }

        public void setFatherLastName(String fatherLastName) {
            this.fatherLastName = fatherLastName;
        }

        public String getSpousePrefix() {
            return spousePrefix;
        }

        public void setSpousePrefix(String spousePrefix) {
            this.spousePrefix = spousePrefix;
        }

        public String getSpouseFirstName() {
            return spouseFirstName;
        }

        public void setSpouseFirstName(String spouseFirstName) {
            this.spouseFirstName = spouseFirstName;
        }

        public String getSpouseMiddleName() {
            return spouseMiddleName;
        }

        public void setSpouseMiddleName(String spouseMiddleName) {
            this.spouseMiddleName = spouseMiddleName;
        }

        public String getSpouseLastName() {
            return spouseLastName;
        }

        public void setSpouseLastName(String spouseLastName) {
            this.spouseLastName = spouseLastName;
        }

        public String getMotherPrefix() {
            return motherPrefix;
        }

        public void setMotherPrefix(String motherPrefix) {
            this.motherPrefix = motherPrefix;
        }

        public String getMotherFirstName() {
            return motherFirstName;
        }

        public void setMotherFirstName(String motherFirstName) {
            this.motherFirstName = motherFirstName;
        }

        public String getMotherMiddleName() {
            return motherMiddleName;
        }

        public void setMotherMiddleName(String motherMiddleName) {
            this.motherMiddleName = motherMiddleName;
        }

        public String getMotherLastName() {
            return motherLastName;
        }

        public void setMotherLastName(String motherLastName) {
            this.motherLastName = motherLastName;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public String getDateofBirth() {
            return dateofBirth;
        }

        public void setDateofBirth(String dateofBirth) {
            this.dateofBirth = dateofBirth;
        }

        public String getWorkEmail() {
            return workEmail;
        }

        public void setWorkEmail(String workEmail) {
            this.workEmail = workEmail;
        }

        public String getPersonalEmail() {
            return personalEmail;
        }

        public void setPersonalEmail(String personalEmail) {
            this.personalEmail = personalEmail;
        }

        public String getPersonalMobileISD() {
            return personalMobileISD;
        }

        public void setPersonalMobileISD(String personalMobileISD) {
            this.personalMobileISD = personalMobileISD;
        }

        public String getPersonalMobileNumber() {
            return personalMobileNumber;
        }

        public void setPersonalMobileNumber(String personalMobileNumber) {
            this.personalMobileNumber = personalMobileNumber;
        }

        public String getWorkMobileISD() {
            return workMobileISD;
        }

        public void setWorkMobileISD(String workMobileISD) {
            this.workMobileISD = workMobileISD;
        }

        public String getWorkMobileNumber() {
            return workMobileNumber;
        }

        public void setWorkMobileNumber(String workMobileNumber) {
            this.workMobileNumber = workMobileNumber;
        }

        public String getPermanentAddressCountry() {
            return permanentAddressCountry;
        }

        public void setPermanentAddressCountry(String permanentAddressCountry) {
            this.permanentAddressCountry = permanentAddressCountry;
        }

        public String getPermanentAddressZipCode() {
            return permanentAddressZipCode;
        }

        public void setPermanentAddressZipCode(String permanentAddressZipCode) {
            this.permanentAddressZipCode = permanentAddressZipCode;
        }

        public String getPermanentAddressLine1() {
            return permanentAddressLine1;
        }

        public void setPermanentAddressLine1(String permanentAddressLine1) {
            this.permanentAddressLine1 = permanentAddressLine1;
        }

        public String getPermanentAddressLine2() {
            return permanentAddressLine2;
        }

        public void setPermanentAddressLine2(String permanentAddressLine2) {
            this.permanentAddressLine2 = permanentAddressLine2;
        }

        public String getPermanentAddressLine3() {
            return permanentAddressLine3;
        }

        public void setPermanentAddressLine3(String permanentAddressLine3) {
            this.permanentAddressLine3 = permanentAddressLine3;
        }

        public String getPermanentAddressDistrict() {
            return permanentAddressDistrict;
        }

        public void setPermanentAddressDistrict(String permanentAddressDistrict) {
            this.permanentAddressDistrict = permanentAddressDistrict;
        }

        public String getPermanentAddressCity() {
            return permanentAddressCity;
        }

        public void setPermanentAddressCity(String permanentAddressCity) {
            this.permanentAddressCity = permanentAddressCity;
        }

        public String getPermanentAddressState() {
            return permanentAddressState;
        }

        public void setPermanentAddressState(String permanentAddressState) {
            this.permanentAddressState = permanentAddressState;
        }

        public String getPermanentAddressDocument() {
            return permanentAddressDocument;
        }

        public void setPermanentAddressDocument(String permanentAddressDocument) {
            this.permanentAddressDocument = permanentAddressDocument;
        }

        public String getPermanentAddressDocumentOthersValue() {
            return permanentAddressDocumentOthersValue;
        }

        public void setPermanentAddressDocumentOthersValue(String permanentAddressDocumentOthersValue) {
            this.permanentAddressDocumentOthersValue = permanentAddressDocumentOthersValue;
        }

        public String getCorrespondenceAddressCountry() {
            return correspondenceAddressCountry;
        }

        public void setCorrespondenceAddressCountry(String correspondenceAddressCountry) {
            this.correspondenceAddressCountry = correspondenceAddressCountry;
        }

        public String getCorrespondenceAddressZipCode() {
            return correspondenceAddressZipCode;
        }

        public void setCorrespondenceAddressZipCode(String correspondenceAddressZipCode) {
            this.correspondenceAddressZipCode = correspondenceAddressZipCode;
        }

        public String getCorrespondenceAddressLine1() {
            return correspondenceAddressLine1;
        }

        public void setCorrespondenceAddressLine1(String correspondenceAddressLine1) {
            this.correspondenceAddressLine1 = correspondenceAddressLine1;
        }

        public String getCorrespondenceAddressLine2() {
            return correspondenceAddressLine2;
        }

        public void setCorrespondenceAddressLine2(String correspondenceAddressLine2) {
            this.correspondenceAddressLine2 = correspondenceAddressLine2;
        }

        public String getCorrespondenceAddressLine3() {
            return correspondenceAddressLine3;
        }

        public void setCorrespondenceAddressLine3(String correspondenceAddressLine3) {
            this.correspondenceAddressLine3 = correspondenceAddressLine3;
        }

        public String getCorrespondenceAddressDistrict() {
            return correspondenceAddressDistrict;
        }

        public void setCorrespondenceAddressDistrict(String correspondenceAddressDistrict) {
            this.correspondenceAddressDistrict = correspondenceAddressDistrict;
        }

        public String getCorrespondenceAddressCity() {
            return correspondenceAddressCity;
        }

        public void setCorrespondenceAddressCity(String correspondenceAddressCity) {
            this.correspondenceAddressCity = correspondenceAddressCity;
        }

        public String getCorrespondenceAddressState() {
            return correspondenceAddressState;
        }

        public void setCorrespondenceAddressState(String correspondenceAddressState) {
            this.correspondenceAddressState = correspondenceAddressState;
        }

        public String getCorrespondenceAddressDocument() {
            return correspondenceAddressDocument;
        }

        public void setCorrespondenceAddressDocument(String correspondenceAddressDocument) {
            this.correspondenceAddressDocument = correspondenceAddressDocument;
        }

        public String getCountryOfResidence() {
            return countryOfResidence;
        }

        public void setCountryOfResidence(String countryOfResidence) {
            this.countryOfResidence = countryOfResidence;
        }

        public String getCountryOfBirth() {
            return countryOfBirth;
        }

        public void setCountryOfBirth(String countryOfBirth) {
            this.countryOfBirth = countryOfBirth;
        }

        public String getBirthCity() {
            return birthCity;
        }

        public void setBirthCity(String birthCity) {
            this.birthCity = birthCity;
        }

        public String getPassportIssueCountry() {
            return passportIssueCountry;
        }

        public void setPassportIssueCountry(String passportIssueCountry) {
            this.passportIssueCountry = passportIssueCountry;
        }

        public String getPassportNumber() {
            return passportNumber;
        }

        public void setPassportNumber(String passportNumber) {
            this.passportNumber = passportNumber;
        }

        public String getPassportExpiryDate() {
            return passportExpiryDate;
        }

        public void setPassportExpiryDate(String passportExpiryDate) {
            this.passportExpiryDate = passportExpiryDate;
        }

        public String getVoterIdNumber() {
            return voterIdNumber;
        }

        public void setVoterIdNumber(String voterIdNumber) {
            this.voterIdNumber = voterIdNumber;
        }

        public String getDrivingLicenseNumber() {
            return drivingLicenseNumber;
        }

        public void setDrivingLicenseNumber(String drivingLicenseNumber) {
            this.drivingLicenseNumber = drivingLicenseNumber;
        }

        public String getDrivingLicenseExpiryDate() {
            return drivingLicenseExpiryDate;
        }

        public void setDrivingLicenseExpiryDate(String drivingLicenseExpiryDate) {
            this.drivingLicenseExpiryDate = drivingLicenseExpiryDate;
        }

        public String getAadhaarNumber() {
            return aadhaarNumber;
        }

        public void setAadhaarNumber(String aadhaarNumber) {
            this.aadhaarNumber = aadhaarNumber;
        }

        public String getAadhaarVaultReferenceNumber() {
            return aadhaarVaultReferenceNumber;
        }

        public void setAadhaarVaultReferenceNumber(String aadhaarVaultReferenceNumber) {
            this.aadhaarVaultReferenceNumber = aadhaarVaultReferenceNumber;
        }

        public String getNregaNumber() {
            return nregaNumber;
        }

        public void setNregaNumber(String nregaNumber) {
            this.nregaNumber = nregaNumber;
        }

        public String getNprLetterNumber() {
            return nprLetterNumber;
        }

        public void setNprLetterNumber(String nprLetterNumber) {
            this.nprLetterNumber = nprLetterNumber;
        }

        public String getDirectorIdentificationNumber() {
            return directorIdentificationNumber;
        }

        public void setDirectorIdentificationNumber(String directorIdentificationNumber) {
            this.directorIdentificationNumber = directorIdentificationNumber;
        }

        public String getFormSixty() {
            return formSixty;
        }

        public void setFormSixty(String formSixty) {
            this.formSixty = formSixty;
        }

        public String getPan() {
            return pan;
        }

        public void setPan(String pan) {
            this.pan = pan;
        }

        public String getCkycNumber() {
            return ckycNumber;
        }

        public void setCkycNumber(String ckycNumber) {
            this.ckycNumber = ckycNumber;
        }

        public String getPoliticallyExposed() {
            return politicallyExposed;
        }

        public void setPoliticallyExposed(String politicallyExposed) {
            this.politicallyExposed = politicallyExposed;
        }

        public String getAdverseReputationDetails() {
            return adverseReputationDetails;
        }

        public void setAdverseReputationDetails(String adverseReputationDetails) {
            this.adverseReputationDetails = adverseReputationDetails;
        }

        public String getNotes() {
            return notes;
        }

        public void setNotes(String notes) {
            this.notes = notes;
        }

        public String getTags() {
            return tags;
        }

        public void setTags(String tags) {
            this.tags = tags;
        }

        public String getScreeningProfile() {
            return screeningProfile;
        }

        public void setScreeningProfile(String screeningProfile) {
            this.screeningProfile = screeningProfile;
        }

        public String getScreeningreportwhennil() {
            return screeningreportwhennil;
        }

        public void setScreeningreportwhennil(String screeningreportwhennil) {
            this.screeningreportwhennil = screeningreportwhennil;
        }

        public String getRiskProfile() {
            return riskProfile;
        }

        public void setRiskProfile(String riskProfile) {
            this.riskProfile = riskProfile;
        }

        public String getAdverseReputation() {
            return adverseReputation;
        }

        public void setAdverseReputation(String adverseReputation) {
            this.adverseReputation = adverseReputation;
        }

        public String getAdverseReputationClassification() {
            return adverseReputationClassification;
        }

        public void setAdverseReputationClassification(String adverseReputationClassification) {
            this.adverseReputationClassification = adverseReputationClassification;
        }

        public List<TaxDetailDto> getTaxDetailDtoList() {
            return taxDetailDtoList;
        }

        public void setTaxDetailDtoList(List<TaxDetailDto> taxDetailDtoList) {
            this.taxDetailDtoList = taxDetailDtoList;
        }

        public String getPoliticallyExposedClassification() {
            return politicallyExposedClassification;
        }

        public void setPoliticallyExposedClassification(String politicallyExposedClassification) {
            this.politicallyExposedClassification = politicallyExposedClassification;
        }

        public String getCitizenships() {
            return citizenships;
        }

        public void setCitizenships(String citizenships) {
            this.citizenships = citizenships;
        }

        public String getNationalities() {
            return nationalities;
        }

        public void setNationalities(String nationalities) {
            this.nationalities = nationalities;
        }

        public List<Document> getDocuments() {
            return documents;
        }

        public void setDocuments(List<Document> documents) {
            this.documents = documents;
        }

        private String segmentStartDate;
        private String status;
        private String effectiveDate;
        private String minor;
        private String maritalStatus;
        private String occupationType;
        private String occupationTypeOther;
        private String natureOfBusinessOther;
        private String companyIdentificationNumber;
        private String companyRegistrationNumber;
        private String companyRegistrationCountry;
        private String globalIntermediaryIdentificationNumber;
        private String kycAttestationType;
        private String kycDateOfDeclaration;
        private String kycPlaceOfDeclaration;
        private String kycVerificationDate;
        private String kycEmployeeName;
        private String kycEmployeeDesignation;
        private String kycVerificationBranch;
        private String kycEmployeeCode;
        private String listed;
        private String applicationRefNumber;
        private String documentRefNumber;
        private String regAMLRisk;
        private String regAMLRiskLastRiskReviewDate;
        private String regAMLRiskNextRiskReviewDate;
        private String incomeRange;
        private double exactIncome;
        private String incomeCurrency;
        private String incomeEffectiveDate;
        private String incomeDescription;
        private String incomeDocument;
        private double exactNetworth;
        private String networthCurrency;
        private String networthEffectiveDate;
        private String networthDescription;
        private String networthDocument;
        private String familyCode;
        private String channel;
        private String contactPersonFirstName1;
        private String contactPersonMiddleName1;
        private String contactPersonLastName1;
        private String contactPersonDesignation1;
        private String contactPersonFirstName2;
        private String contactPersonMiddleName2;
        private String contactPersonLastName2;
        private String contactPersonDesignation2;
        private String contactPersonMobileISD;
        private String contactPersonMobileNo;
        private String contactPersonMobileISD2;
        private String contactPersonMobileNo2;
        private String contactPersonEmailId1;
        private String contactPersonEmailId2;
        private String commencementDate;
        private String maidenPrefix;
        private String maidenFirstName;
        private String maidenMiddleName;
        private String maidenLastName;
        private int relatedPersonCountforCKYC;
        private String proofOfIdSubmitted;
        private String products;
        private String natureOfBusiness;
        private String educationalQualification;
        private String countryOfOperations;
        private List<RegAMLRiskSpecialCategoryDto> regAMLRiskSpecialCategoryDtoList;
        private List<RelatedPerson> relatedPersonList;
        private List<CustomerRelationDto> customerRelationDtoList;
        private String constitutionType;
        private int constitutionTypeId;
        private String sourceSystemCustomerCode;
        private String sourceSystemCustomerCreationDate;
        private String uniqueIdentifier;
        private String prefix;
        private String firstName;
        private String middleName;
        private String lastName;
        private String fatherPrefix;
        private String fatherFirstName;
        private String fatherMiddleName;
        private String fatherLastName;
        private String spousePrefix;
        private String spouseFirstName;
        private String spouseMiddleName;
        private String spouseLastName;
        private String motherPrefix;
        private String motherFirstName;
        private String motherMiddleName;
        private String motherLastName;
        private String gender;
        private String dateofBirth;
        private String workEmail;
        private String personalEmail;
        private String personalMobileISD;
        private String personalMobileNumber;
        private String workMobileISD;
        private String workMobileNumber;
        private String permanentAddressCountry;
        private String permanentAddressZipCode;
        private String permanentAddressLine1;
        private String permanentAddressLine2;
        private String permanentAddressLine3;
        private String permanentAddressDistrict;
        private String permanentAddressCity;
        private String permanentAddressState;
        private String permanentAddressDocument;
        private String permanentAddressDocumentOthersValue;
        private String correspondenceAddressCountry;
        private String correspondenceAddressZipCode;
        private String correspondenceAddressLine1;
        private String correspondenceAddressLine2;
        private String correspondenceAddressLine3;
        private String correspondenceAddressDistrict;
        private String correspondenceAddressCity;
        private String correspondenceAddressState;
        private String correspondenceAddressDocument;
        private String countryOfResidence;
        private String countryOfBirth;
        private String birthCity;
        private String passportIssueCountry;
        private String passportNumber;
        private String passportExpiryDate;
        private String voterIdNumber;
        private String drivingLicenseNumber;
        private String drivingLicenseExpiryDate;
        private String aadhaarNumber;
        private String aadhaarVaultReferenceNumber;
        private String nregaNumber;
        private String nprLetterNumber;
        private String directorIdentificationNumber;
        private String formSixty;
        private String pan;
        private String ckycNumber;
        private String politicallyExposed;
        private String adverseReputationDetails;
        private String notes;
        private String tags;
        private String screeningProfile;
        private String screeningreportwhennil;
        private String riskProfile;
        private String adverseReputation;
        private String adverseReputationClassification;
        private List<TaxDetailDto> taxDetailDtoList;
        private String politicallyExposedClassification;
        private String citizenships;
        private String nationalities;
        private List<Document> documents;

        // Getters and Setters
    }

    public static class RegAMLRiskSpecialCategoryDto {
        private String regAMLRiskSpecialCategory;
        private String regAMLRiskSpecialCategoryStartDate;

        // Getters and Setters

        public String getRegAMLRiskSpecialCategory() {
            return regAMLRiskSpecialCategory;
        }

        public void setRegAMLRiskSpecialCategory(String regAMLRiskSpecialCategory) {
            this.regAMLRiskSpecialCategory = regAMLRiskSpecialCategory;
        }

        public String getRegAMLRiskSpecialCategoryStartDate() {
            return regAMLRiskSpecialCategoryStartDate;
        }

        public void setRegAMLRiskSpecialCategoryStartDate(String regAMLRiskSpecialCategoryStartDate) {
            this.regAMLRiskSpecialCategoryStartDate = regAMLRiskSpecialCategoryStartDate;
        }
    }

    public static class RelatedPerson {
        // Define fields as needed
    }

    public static class CustomerRelationDto {
        // Define fields as needed
    }

    public static class TaxDetailDto {
        private String taxResidencyCountry;
        private String taxIdentificationNumber;
        private String taxResidencyStartDate;
        private String taxResidencyEndDate;

        // Getters and Setters

        public String getTaxResidencyCountry() {
            return taxResidencyCountry;
        }

        public void setTaxResidencyCountry(String taxResidencyCountry) {
            this.taxResidencyCountry = taxResidencyCountry;
        }

        public String getTaxIdentificationNumber() {
            return taxIdentificationNumber;
        }

        public void setTaxIdentificationNumber(String taxIdentificationNumber) {
            this.taxIdentificationNumber = taxIdentificationNumber;
        }

        public String getTaxResidencyStartDate() {
            return taxResidencyStartDate;
        }

        public void setTaxResidencyStartDate(String taxResidencyStartDate) {
            this.taxResidencyStartDate = taxResidencyStartDate;
        }

        public String getTaxResidencyEndDate() {
            return taxResidencyEndDate;
        }

        public void setTaxResidencyEndDate(String taxResidencyEndDate) {
            this.taxResidencyEndDate = taxResidencyEndDate;
        }
    }

    public static class Document {
        // Define fields as needed
    }
}
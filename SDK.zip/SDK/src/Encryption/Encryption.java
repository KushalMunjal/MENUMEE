package Encryption;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Base64;

public class Encryption {
/*

    Following are the steps to be followed for encryption:
    1.Generate a Session Key of 256 bits.
    2.Encrypt the request data using AES (Symmetric 128 bits) algorithm with the above generated Session Key
    3.Encode the above encrypted data to Base64 string.
    4.Encrypt the session key using the Public Key of the Receiver, using RSA (Asymmetric Algorithm).
    5.Encode the above encrypted Session Key to Base64 string.
    6.Combine the encrypted data and encrypted session key into a string and then sign that string using the sender's private key.
    7.Add this encrypted and encoded data, session Key and signature to the request.
    8.Note: Key sizes acceptable: - 1024,2048 bits

*/

    private static final int sessionkey_size = 256;
    public static Object encryptData(String requestData, PublicKey receiverPublicKey, PrivateKey senderPrivateKey) throws Exception{

        try{
            String requestid1 = "a795a235-60d2-4f59-b6f6-078f6648fd71";

            // Generate a SessionKey of 256 bits
            SecretKey sessionKey = generateSessionKey();

            //Encrypt the Request data using AES using Sessionkey
            byte[] encryptData = encryptWithAES(requestData, sessionKey);

            //Encoding the Encrypted data to Base64 string
            String encodedData = tobase64Encode(encryptData);

            //Encrypt the Sessionkey using the public key of receiver
            byte[] encryptedSessionKey = encryptWithRSA(sessionKey.getEncoded(),receiverPublicKey);

            //Encode encrypted sessionkey to base64 string
            String encodedSessionKey = tobase64Encode(encryptedSessionKey);


            //Combining the Encrypted Data and Encrypted SessionKey into String
            String combinedString = encodedData + encodedSessionKey;

            String encodedsignature = SecureSignature.signData(encodedData,encodedSessionKey,combinedString,senderPrivateKey);

            return new EncryptedDetails(requestid1,encodedData,encodedSessionKey,encodedsignature);

        }catch(Exception e){
            e.printStackTrace();
            return null;
        }

    }
    private static SecretKey generateSessionKey() throws NoSuchAlgorithmException {

        try {
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(sessionkey_size);
            return keyGen.generateKey();
        } catch (Exception e) {
            throw new RuntimeException("Error Generating Key:",e);
        }
    }

    private static byte[] encryptWithAES(String requestData, SecretKey sessionKey) throws Exception {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE,sessionKey);
            return cipher.doFinal(requestData.getBytes());
        } catch (Exception e) {
            throw new RuntimeException("Error Encrypting AES:",e);
        }
    }

    private static String tobase64Encode(byte[] encryptData) {
        return Base64.getEncoder().encodeToString(encryptData);
    }

    private static byte[] encryptWithRSA(byte[] encoded, PublicKey receiverPublicKey) {
        try {
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.ENCRYPT_MODE,receiverPublicKey);
            return cipher.doFinal(encoded);
        } catch (Exception e) {
            throw new RuntimeException("Error Encrypting AES:",e);
        }
    }

}

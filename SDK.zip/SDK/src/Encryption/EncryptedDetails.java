package Encryption;
public class EncryptedDetails {
    private final String requestid;
    private final String encryptedData;
    private final String encryptedSessionKey;
    private final String signature;

    public EncryptedDetails(String requestid, String encryptedData, String encryptedSessionKey, String signature) {
        this.requestid = requestid;
        this.encryptedData = encryptedData;
        this.encryptedSessionKey = encryptedSessionKey;
        this.signature = signature;
    }

    public String getRequestid() {
        return requestid;
    }
    public String getEncryptedData() {
        return encryptedData;
    }

    public String getEncryptedSessionKey() {
        return encryptedSessionKey;
    }

    public String getSignature() {
        return signature;
    }
}

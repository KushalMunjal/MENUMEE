package Encryption;

import java.security.PrivateKey;
import java.security.PublicKey;

public class Decryption {

    /*
        Following are the steps to decrypt and read the response:
        1.Verify the signature in Response using the Public Key of the Sender.
        2.Decode the Session Key from the Response.
        3.Decrypt the above Session Key by Receiver’s Private Key using RSA (Asymmetric Algorithm)
        4.Decode the data in Response.
        5.Decrypt the data by Session Key (derived from above) using AES (Symmetric Algorithm).

    */
    public static String decryptData(String encryptedData, PrivateKey receiverPrivatekey, PublicKey senderPublicKey){
        try{

        }catch (Exception e){
            e.printStackTrace();
        }
    }

}

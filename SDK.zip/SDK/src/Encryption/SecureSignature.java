package Encryption;

import java.security.PrivateKey;
import java.security.*;
import java.util.Base64;

public class SecureSignature {

    /*

    Following are the steps to be followed for Signature After Encryption:
    6.Combine the encrypted data and encrypted session key into a string and then sign that string using the sender's private key.
    7.Add this encrypted and encoded data, session Key and signature to the request.

    Following are the steps to decrypt and read the response:
    1.Verify the signature in Response using the Public Key of the Sender.

    */
    public static String signData(String combinedString, PrivateKey senderPrivateKey){
        try{
            byte[] signatureBytes = generateSignature(combinedString,senderPrivateKey);
            String encodedSignature = base64Encode(signatureBytes);
            return combinedString + encodedSignature;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String base64Encode(byte[] signatureBytes) {
        return Base64.getEncoder().encodeToString(signatureBytes);
    }

    private static byte[] generateSignature(String combinedString, PrivateKey senderPrivateKey) throws Exception{
        try {
            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initSign(senderPrivateKey);
            signature.update(combinedString.getBytes());
            return signature.sign();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    private static byte[] base64Decode(String data) {
        return Base64.getDecoder().decode(data);
    }
    private static boolean verifySignature(String combinedString, String signature,PublicKey senderPublicKey) throws NoSuchAlgorithmException, InvalidKeyException {
        try {
            byte[] signatureBytes = base64Decode(signature);

            Signature verifier = Signature.getInstance("SHA256withRSA");
            verifier.initVerify(senderPublicKey);
            verifier.update(combinedString.getBytes());

            return verifier.verify(signatureBytes);

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
